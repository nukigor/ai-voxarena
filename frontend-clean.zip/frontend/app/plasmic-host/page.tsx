// frontend/app/plasmic-host/page.tsx
"use client";

import { PlasmicCanvasHost } from "@plasmicapp/host";

export default function PlasmicHost() {
  return <PlasmicCanvasHost />;
}