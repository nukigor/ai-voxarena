-- AlterTable
ALTER TABLE "public"."Persona" ADD COLUMN     "avatarUrl" TEXT;
